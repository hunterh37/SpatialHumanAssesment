Buddy, the mascot. Spec: `specs/mascot.md`.

- `buddy-demo.html` interactive 3D prototype (three.js). Open it in a browser. Move the pointer to move the hand; hold the mouse button or press Space to open it. "Scored trial" sends Buddy to its perch. All behavior numbers in the spec come from this file.
- `betteryears-logo.html` five logo directions for BetterYears, built on the Dusk spec. Concepts only; nothing here ships in the app yet.

Both files are self-contained and need an internet connection for fonts and the three.js library.
