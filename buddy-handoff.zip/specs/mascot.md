# Buddy, the mascot

Status: concept approved, ready to build. Owner: Alex (design). Reference prototype: `concept/buddy/buddy-demo.html` (open it in a browser; it runs the full behavior below with a simulated hand). Logo directions: `concept/buddy/betteryears-logo.html`.

Buddy is a small, round plush bird that keeps the participant company in the immersive space between games. It flies around, lands on an open palm, and naps on a perch during every block of trials. It never takes part in a game and never changes timing or scoring.

## For the agent implementing this

1. Read this file, `specs/games/design.md`, `concept/SpatialAge_Dusk_Design_Spec.pdf` (sections 0 to 4), then open the prototype and watch one full cycle.
2. Work on a branch `feature/buddy-mascot`, one PR into `main`. No schema change is needed; do not touch `packages/schema` or ScoreKit.
3. Match the prototype's numbers in this spec. Where this spec and the prototype differ, this spec wins (the prototype puts the perch in view so it reads on a flat screen).
4. Build in the simulator first: hand tracking is unavailable there, so Buddy should wander, rest and wake correctly without hands. Then test the palm landing on device.
5. Add `mascot.md` to the index in `specs/README.md` in the same PR.

## Code

New folder `apps/vision/SpatialAge/Sources/Mascot/`:

| File | What it holds |
|---|---|
| `Buddy.swift` | `@MainActor final class Buddy`: builds the model, owns the perch, runs the state machine. Public API below. |
| `BuddyModel.swift` | Mesh and material construction (sizes and colors tables below). |
| `PalmReader.swift` | Open-hand detection from hand joints: openness, palm normal, landing point, hand speed. |

Changes to existing files:

| File | Change |
|---|---|
| `Tracking/HandTracker.swift` | Extend `HandState` with the extra joints `PalmReader` needs (see Palm detection). They are already computed in `run()` by `joint(_:)`; store them. |
| `Stage/ImmersiveView.swift` | `@State private var buddy: Buddy?`. Create it in `run()` once the tracker exists, add `buddy.root` to the content (not to `layer`, which `halt()` clears), and call `buddy.update(dt:)` inside the existing `SceneEvents.Update` closure next to `anatomy.update`. Remove Buddy in `halt()`. |
| `Games/Minigame.swift` | `GameContext` gains `let buddy: Buddy?` (init parameter, default `nil`). |
| `Stage/Director.swift` | Rest and wake calls around each block (see Integration). |
| `Design/Tone.swift` | New cue `.chirp` (see Sound). |
| `Design/Meshes.swift` | `splitSphere` helper (see Model). |

Public API:

```swift
@MainActor final class Buddy {
    let root: Entity
    init(clock: FrameClock, tracker: HandTracker, handedness: Participant.Handedness)
    func update(dt: Double)                          // every frame, from SceneEvents.Update
    func placePerch(rig: Rig)                        // call after ctx.recenter()
    func rest()                                      // fly to the perch and nap; idempotent
    func settled(timeout: Double) async              // returns once resting, or after timeout
    func wake(celebrate: Bool)                       // leave the perch and fly free
}
```

## Integration with every game

Buddy is the same in all eight games because it hooks into `Director`, not into the games. No game file changes.

```swift
// Director.run, per game
ctx.recenter()
ctx.buddy?.placePerch(rig: ctx.rig)
...
for familiarization in [true, false] {
    ctx.show(game, familiarization: familiarization, total: n)
    ctx.buddy?.rest()                                 // starts flying to the perch during the intro
    await ctx.clock.wait(familiarization ? 2.5 : 1.8)
    await ctx.buddy?.settled(timeout: 2.0)            // waits only if Buddy is still in the air
    await ctx.countdown()
    let block = await instance.play(...)              // Buddy is still and silent for the whole block
    ...
    ctx.cheer(...)
    if !familiarization { ctx.buddy?.wake(celebrate: true) }
    await ctx.clock.wait(1.4)
}
```

Rules:

- Buddy rests for every block, practice included, because practice also shows targets.
- Between practice and the scored block it stays on the perch.
- After the scored block it wakes, flies one 0.5 m circle above the perch and chirps twice (the celebration), then flies free until the next game's intro.
- At session start Buddy flies in from 4 m ahead, 1 m above eye level, during the existing 1.5 s settle wait.
- `settled` must never be awaited inside `play`. Buddy never adds time inside a block.

## Behavior

States and transitions. All distances in meters, times in seconds, angles in radians unless marked.

| State | Does | Leaves when |
|---|---|---|
| `wander` | Flies between random points in the wander box. 1.1 s of wingbeats, then 1.7 s glide (cycle 2.8 s). Cruise 1.1 m/s, sinks 0.18 m/s while gliding. New target on arrival (< 0.35) or after 8 s. | `rest()` → `toRest`. Palm call → `called`. |
| `called` | Glides to an approach point 0.4 in front of and 0.24 above the landing point, blending onto the landing point as it nears (k = clamp((d − 0.2) / 1.0, 0, 1)). Speed min(1.6, 0.4 + 1.8 d). Wingbeat 3.8 Hz. | Within 0.42 of the landing point → `landing`. Hand closes → `wander`. `rest()` → `toRest`. |
| `landing` | Velocity toward the landing point, 3.5 × offset, capped 1.0 m/s. Wingbeat 5 Hz, feet out, body pitches nose-up to 0.5 over 0.4 s (the flare). | Distance < 0.015, or < 0.04 after 0.7 s, or 2.0 s elapsed → `perched`. Hand closes → `takeoff`. |
| `perched` | Rides the palm (position follows the landing point, damping rate 30/s). Wings folded, faces the participant, head glances every 1.2 to 3 s (yaw ±0.8, tilt ±0.3), small hop-and-turn every 4 to 8 s (0.26 s, 1.8 cm high), tail bob. Chirps 3 times on arrival. | Hand closes, palm turns down, or hand speed > 2.5 m/s → `takeoff`. `rest()` → `takeoff`, then `toRest`. |
| `takeoff` | Hops up and away: start velocity (±0.4, 1.1, toward the scene 0.7), wingbeat 4.2 Hz. Chirps once. | After 0.9 s → `wander`, or `toRest` if a rest is pending. |
| `toRest` | Same glide as `called`, toward the perch, max 1.5 m/s, wingbeat 3.6 Hz. | Within 0.42 → `restLanding`. |
| `restLanding` | Same as `landing`, onto the perch. | Down → `resting`. |
| `resting` | Completely still: wings folded, head tucked (yaw 0.35, tilt 0.22), eyes closed after 0.8 s, no blink, no hop, no tail bob, no sound. | `wake()` → `takeoff`. |

Smoothing (exponential, `x += (target − x) × (1 − e^(−rate·dt))`):

| Value | Rate |
|---|---|
| Velocity steering | wander 1.6, approach 2.6, landing 5, takeoff 1.4 |
| Yaw | 4.5 in flight, 5 when perched |
| Pitch | 4 (in flight: 0.7 × climb angle, plus the flare) |
| Roll | 3. Bank into turns: 0.22 × yaw rate, clamped to ±0.55 |
| Wingbeat amplitude | 3.5 |
| Wing fold | 5 |
| Feet out | 6 |
| Head | 9 |

Wings: per frame `phase += dt × hz × 2π`; `wave(p) = sin p + 0.22 sin 2p` (downstroke a little quicker than the upstroke); `spread = 1.35 − 0.65·amp + 0.75·amp·wave(phase)`; wing angle = `0.06·fold + (1 − fold)·spread`. Each wing: rotate about its own z by `side × angle` (side +1 for the wing on +x), then tilt back 0.45 about x. Body bobs 3 mm with the wingbeat. Amp is 0.85 flapping, 0 gliding (wings held wide), 0 folded.

Blink every 2 to 5 s for 0.12 s (eyes scale to 15 % height), except while resting.

## Where Buddy may go

All positions are rig-local (`Rig`: x right, y up, −z forward, origin on the floor under the head), with `eye = rig.eye`.

| Zone | Where | Why |
|---|---|---|
| Wander box | x −1.5 to 1.5, y eye − 0.15 to eye + 0.8, z −1.8 to −3.2 | Outside arm's reach (0.35 to 0.9 m), beyond the HUD panel at 1.2 m |
| Perch | 2.2 m out at azimuth 135° on the non-dominant side (left for right-handed and ambi), top at eye − 0.45 | Outside every target arc: Spark goes to 120° eccentricity, Color Dots to ±100°, Constellation to ±70° |
| Hand | Only when called | The one time Buddy enters the play space |

The prototype shows the perch in front-left so it is visible on a laptop screen. On device it sits behind-left: a short head turn shows Buddy napping, and it can never sit behind a target.

The perch is a small post and branch Buddy owns: post 1.1 m tall scaled to `eye − 0.45`, radius 0.03 to 0.05, a 0.38 m branch across the top, color `tree` #3A363C, roughness 0.95. Buddy lands 9 cm along the branch.

## Palm detection

`PalmReader` reads each tracked hand every frame. Store these joints in `HandState` (all are in `HandTracker.jointOrder`): `wrist`, the four finger `Knuckle`, `IntermediateBase`, `IntermediateTip`, `Tip` joints, `thumbKnuckle`, `thumbIntermediateBase`, `thumbIntermediateTip`, `thumbTip`.

| Measure | Formula |
|---|---|
| Finger extension | straight-line knuckle to tip ÷ summed segment lengths (knuckle → base → intermediate tip → tip). 1.0 is straight. Thumb uses its own chain. |
| Open | every finger and the thumb > 0.90 (about 25° per joint) |
| Closed | any finger < 0.80 (about 45°). Between 0.80 and 0.90 keep the last state (hysteresis). |
| Palm normal | `c = normalize(cross(indexKnuckle − wrist, littleKnuckle − wrist))`; right hand `n = c`, left hand `n = −c`. Check on device that a palm held up gives `n.y > 0`; if not, flip both. |
| Palm up | `n.y > 0.64` (within 50° of vertical) to call; turned past 100° (`n.y < −0.17`) releases |
| Reach | wrist 0.25 to 0.75 m from the head |
| Landing point | `(wrist + middleKnuckle) / 2 + n × 0.01`, then + `n × 0.098` (Buddy's feet sit 9.8 cm below its center) |
| Hand speed | wrist velocity, smoothed at rate 12 |
| Call | open, palm up, in reach, held 0.35 s continuously |

If both hands qualify, use the one that qualified first. A hand that goes untracked (`HandTracker.staleS`) counts as closed.

## Model

Buddy faces −z (RealityKit convention). Build at these sizes, then scale the whole root by 1.3. Colors are Dusk tokens except the face white, which is derived between `fg` and `sun` as the spec allows.

| Part | Shape (meters, before the 1.3 scale) | Position | Color |
|---|---|---|---|
| Body | ellipsoid radius 0.062, scale (1, 1.04, 0.98) | (0, −0.008, 0.004) | back `accent` #FBDAB4, face `white` #FFF8EC |
| Head | ellipsoid radius 0.046, scale (1, 0.96, 1) | (0, 0.034, −0.024) | same split |
| Beak | truncated cone radius 0.011 to 0.003, length 0.022, tip tilted up 0.15 | head + (0, 0.002, −0.052) | `hill` #4E4B51 |
| Eyes | sphere 0.0068, glint sphere 0.002 offset (±0.0016, 0.003, −0.005) | head + normalize(±0.6, 0.22, −0.77) × 0.0455 | `treeDark` #252322, roughness 0.15; glint unlit white |
| Cheeks | flat ellipse 0.0085 × 0.0052, facing out | head + normalize(±0.7, −0.08, −0.71) × 0.0458 | `cloud` #E9B9A0, unlit |
| Wings | ellipsoid radii (0.013, 0.034, 0.044) offset (0, −0.027, 0.012) so it hangs from its pivot | pivot (±0.052, 0.012, 0.006) | `accentStrong` #D8AB8B, tip slate below y = −0.05 |
| Tail | ellipsoid radii (0.022, 0.009, 0.032) offset z +0.012 | (0, −0.012, 0.06), lifted 0.45 | `accentStrong` |
| Feet | per foot 3 toes forward at −0.55, 0, 0.55 rad (0.016 long) and 1 back (0.01), radius 0.0022 | (±0.02, −0.075, −0.012), splayed 0.25 | `hill`. Scale with "feet out" so they show only when landing or perched |

Face and body color split: one mesh, two materials. Add `Meshes.splitSphere(radius:scale:segments:isB:)` that builds a UV sphere (48 × 32) as a `MeshDescriptor`, uses ellipsoid normals `normalize(p / scale²)`, and sets `materials = .perFace(...)`: a triangle uses material 1 when its centroid direction `d` satisfies `−d.z − 0.45·d.y + bias > 0` (body bias 0.12, head −0.02). The wing uses the same helper with `y < −0.05` for the slate tip.

Materials: `PhysicallyBasedMaterial`, roughness 0.85, metallic 0, so Buddy reads as soft matte plush. Add a faint sheen if the SDK's `sheen` property is available. Keep it clean: no noise, texture or fur shells. They made it look dirty in review.

Never use the four signal colors (go, nogo, gold, teal) anywhere on Buddy or the perch.

## Sound

Add `Tone.Cue.chirp`: three sine partials (1, 0.3, 0.1) whose base frequency sweeps from f0 up to 1.55 f0 over 55 ms and settles to 1.15 f0 by 100 ms, with f0 between 2300 and 2900 Hz. Duration 0.11 s, 12 ms attack. Integrate the phase per sample so the sweep has no clicks. Cache a few f0 variants. Play from `buddy.root` at gain −18 dB.

| Moment | Chirps |
|---|---|
| Lands on a palm | 3, 0.12 to 0.18 s apart |
| Takes off | 1 |
| Celebrates after a scored block | 2 |
| Any time a block is running | none |

## Dusk rules it follows

- Still and silent during every block. The only motion in view during play is a game signal (`design.md`).
- Outside the play space unless called. Never behind a target.
- Colors from the Dusk tokens only. No signal colors.
- Respect Reduce Motion (`UIAccessibility.isReduceMotionEnabled`): no hops, no head glances, glide more and flap less (amp 0.5).
- Copy, if Buddy ever gets a line: calm, short, no exclamation marks, never a health claim.

## Done

- Buddy appears at session start, wanders between games, and rests on the perch before every block's countdown in all eight games.
- During blocks Buddy does not move and makes no sound. Block timing is unchanged: compare `start_t` gaps in a session file with and without Buddy.
- On device, an open palm held up for 0.35 s brings Buddy to the hand within 3 s from anywhere in the wander box, and closing the hand sends it off.
- Simulator: no crash and no hang without hand tracking. Buddy wanders, rests and wakes.
- `specs/README.md` lists `mascot.md`.

## Open

- Perch at 135° means Buddy naps out of view. If the team wants it visible during play, try azimuth 75 to 80° and check it against Spark and Color Dots spawn arcs on device.
- The approach to a palm may cross the HUD panel (center 1.75 m high, 1.2 m ahead). If it looks wrong, offset the approach point 0.3 m toward the hand's side.
- Results and catalog windows could show Buddy as a small `RealityView` next to the movement age. Not in this PR.
- App name: the brand is moving to BetterYears (see the logo concept). Renaming the app target and display name is a separate change.
